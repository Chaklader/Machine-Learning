computational-investing-georgia-tech
====================================

Homework for Computation Investing Class at Georgia Tech
