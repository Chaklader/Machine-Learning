import itertools as f
for i in f.combinations(['SPY','IBM','GLD','AAA','RSP','QQQ'],4):print i

